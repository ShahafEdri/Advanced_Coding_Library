
#include <stdio.h>
#include <stdlib.h>
#include "Queue_arr.h"
#include "Stack_arr.h"

int isEven(int num) {
	return 1 - num % 2;
}

int isOdd(int num) {
	return 1 - isEven(num);
}

int* createArray(int size) {
	int* ptrAdress;
	ptrAdress = (int*)malloc(size * sizeof(int));
	for (int i = 0; i < size; i++) {
		scanf_s("%d", &ptrAdress[i]);
	}
	return ptrAdress;
}

void printArray(int* ptrAdress, int size) {
	for (int i = 0; i < size; i++) {
		printf("%d", ptrAdress[i]);
	}
}

int isPolindrom(char* arr, int size) {
	char var1;
	char var2;
	stack* stack1 = (stack*)malloc(1 * sizeof(stack)); //stack size == 100
	stack* stack2 = (stack*)malloc(1 * sizeof(stack)); //stack size == 100
	create_stack(stack1);
	create_stack(stack2);
	for (int i = 0; i < size / 2; i++) {
		push(arr[i], stack1);
		push(arr[size - 1 - i], stack2);
	}
	for (int i = 0; i < size / 2; i++) {
		pop(stack1, &var1);
		pop(stack2, &var2);
		if (!(var1 == var2)) {
			return 0;
		}
	}
	return 1;
}

//			V
//			1|2|3|4|3|2|1|	==>	size_of_stack %2? 
//			1|2|3|4|5|6|7|

//stack 1	1|3|
//stack 2	2|

queue* sortQueByEven(queue que, int sizeOfQue) {
	int tmp;
	queue* evenQue = (queue*)malloc(1 * sizeof(queue));
	queue* oddQue = (queue*)malloc(1 * sizeof(queue));
	create_queue(evenQue);
	create_queue(oddQue);
	for (int i = 0; i < sizeOfQue; i++) {
		dequeue(&que, &tmp);
		if (isEven(tmp))
			enqueue(tmp, evenQue);
		else
			enqueue(tmp, oddQue);
	}
	int evenCount = evenQue->items_num;
	for (int i = 0; i < evenCount; i++) {
		if (dequeue(evenQue, &tmp))
			enqueue(tmp, &que);
	}
	int oddCount = oddQue->items_num;
	for (int i = 0; i < oddCount; i++) {
		if (dequeue(oddQue, &tmp))
			enqueue(tmp, &que);
	}
	return &que;
}




#define SIZE 3
#define SIZE1 5

int main() {

	//char arr[SIZE] = { 'm','o','m' }; // '\0'
	//int size = SIZE;
	//int flag = isPolindrom(arr, size);
	//printf("the arr %s a Polindrom", flag ? "IS" : "IS NOT");

	unsigned int arr1[SIZE1] = { 1,2,3,4,5 };
	int sizeOfarr1 = SIZE1;
	int tmp = (int*)malloc(1 * sizeof(int));
	queue* que = (queue*)malloc(1 * sizeof(queue));
	//queue* que;
	create_queue(que);
	for (int i = 0; i < SIZE1; i++) {
		enqueue(arr1[i], que);
	}
	que = sortQueByEven(*que, sizeOfarr1);
	for (int i = 0; i < SIZE1; i++) {
		dequeue(que, &tmp);
		printf("%d ", tmp);
	}
}

